
package LivingBeingUse;
import Mamals.Mamal;

public class Use {

	public static void main(String[] args) {
		
		Founder.found(new Executive());
		Founder.study(new Executive());

	}

}
