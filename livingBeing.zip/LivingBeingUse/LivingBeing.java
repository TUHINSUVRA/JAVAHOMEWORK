





public  interface LivingBeing {
	
	void breathIn();
	void breathOut();
}
