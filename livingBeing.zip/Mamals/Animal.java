package Mamals;

import LivingBeingUse.LivingBeing;

public interface Animal  extends LivingBeing {
	
	
	
	
	void fear();/*{
		System.out.println("fear of death...");
	}*/
	void eat();/* {
		System.out.println("eating.......");
	}*/
	void sleep(); /*{
		System.out.println("sleeping......");
	}*/
	void reproduction();/* {
		System.out.println("reproduction......");
	}*/
}
