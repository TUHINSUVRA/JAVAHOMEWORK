package Mamals;

import Mamals.Founder.Business;

public interface Mamal extends Animal{
	void giveBirth();
}
interface Human extends Mamal {
	void think();
}
interface Person extends Human{
	void active();
}
interface Student extends Person{

	void study(Executive e);
}
interface Employee extends Student
{
	void work();
}
interface Executive extends Employee
{
	void execute();
}
interface Manager extends Executive
{
	Business manage(); 
}
interface Director extends Manager
{
	void direct();
	
}

class Founder implements Director
{
	void found(Executive e) {
		System.out.println("Found a company.....");
		e.execute();
		e.active();
		e.breathIn();
		//e.manage();//not an inherited or exclusive  method of Executive
	}
	
	
	@Override
	public void work() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void study(Executive e) {
		e.execute();
	}
	
	@Override
	public void active() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void think() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void giveBirth() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void fear() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void eat() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void sleep() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void reproduction() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void breathIn() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void breathOut() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void direct() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Business manage() {  //interface 
		
		return new Business();
		
		
		// TODO Auto-generated method stub
		
	}
	
	class Business{}
	
	
	@Override
	public void execute() {
		System.out.println("Executive is executing");
		
	}
}