package com.sbi.dashboard;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.dashboard.controller.AccountController;
import com.sbi.dashboard.controller.CustomerController;
import com.sbi.dashboard.entity.Account;
import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.repository.CustomerRepository;
import com.sbi.dashboard.repository.TransactionRepository;
import com.sbi.dashboard.service.CustomerService;

@SpringBootTest
class MyDashboardProjectApplicationTests {

	@Autowired
	CustomerRepository custRepo;
	
	@Test
	void testCustRepo() {
		
		Customer cust=custRepo.getCustomerById(1015);
		System.out.println("customer email id is :"+cust.getCustEmail());
		System.out.println("customer mobile id is :"+cust.getCustMo());
		System.out.println("customer falt no is :"+cust.getAddress().getFlatNO());
		System.out.println("customer address is :"+cust.getAddress().getStreetname());
		System.out.println("customer address is :"+cust.getAddress().getCity());
		System.out.println("customer address is :"+cust.getAddress().getState());
		System.out.println("customer address is :"+cust.getAddress().getPin());
		System.out.println("customer address is :"+cust.getAddress().getCountry());
		
		
	}




	@Autowired
	CustomerService custServ;
	
	@Test
	void testCustServ() {
	
	Customer cust=custServ.getCustomerByIdService(1011);
	System.out.println("customer email id is :"+cust.getCustEmail());
	System.out.println("customer mobile id is :"+cust.getCustMo());
	System.out.println("customer falt no is :"+cust.getAddress().getFlatNO());
	System.out.println("customer street is :"+cust.getAddress().getStreetname());
	System.out.println("customer city is :"+cust.getAddress().getCity());
	System.out.println("customer Sate is :"+cust.getAddress().getState());
	System.out.println("customer Pin is :"+cust.getAddress().getPin());
	System.out.println("customer country is :"+cust.getAddress().getCountry());
	
	
	}
	@Autowired
	CustomerController controller;
	
	@Autowired
	TransactionRepository txnRepo;
	
	@Test
	public void testFundTransfer() {
		
		System.out.println("INSIDE TEST CLASS");
		
		txnRepo.fundTransfer(null, 2015000005,2019000009, 1000);
		
	}

	@Test
	void testCustimpl() {
		
		Customer cust=controller.getCustomerByIdController(1016);
		System.out.println("customer email id is :"+cust.getCustEmail());
		System.out.println("customer mobile id is :"+cust.getCustMo());
		System.out.println("customer falt no is :"+cust.getAddress().getFlatNO());
		System.out.println("customer address is :"+cust.getAddress().getStreetname());
		System.out.println("customer address is :"+cust.getAddress().getCity());
		System.out.println("customer address is :"+cust.getAddress().getState());
		System.out.println("customer address is :"+cust.getAddress().getPin());
		System.out.println("customer address is :"+cust.getAddress().getCountry());
		try {
		ObjectMapper map = new ObjectMapper();
		System.out.println(map.writeValueAsString(cust));
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		
	}

	@Autowired
	AccountController accctrl;
	@Test
	void testAccCtrl() {
		List<Account> acc=accctrl.findAccountforSingleCustomer(1015);
		for(Account a:acc) {
			System.out.println("customer balance id is :"+a.getAccBalance());
			System.out.println("customer balance id is :"+a.getAccBranch());
			
		}
		
	}
}
