package com.sbi.dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyDashboardProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
