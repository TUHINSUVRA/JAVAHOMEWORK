package com.sbi.dashboard.controller;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.dashboard.entity.Account;
import com.sbi.dashboard.service.AccountService;




@CrossOrigin
@RestController
@RequestMapping("/myaccount")
public class AccountController {
	
	@Autowired
	AccountService acctServ;
	
	@RequestMapping("/{custNo}")
	public List<Account> findAccountforSingleCustomer (@PathVariable("custNo") int cNo) {
		
		System.out.println("AccountController: findAllAccounts for one Customer No(int) is invoked...."+cNo);
		List<Account> acc=acctServ.getAllAccountsSingleCustomerService(cNo);
		//customer = acctServ.getCustomerByIdService(cNo);
		 
		//return customer;
		return acc;
		
	}

}
