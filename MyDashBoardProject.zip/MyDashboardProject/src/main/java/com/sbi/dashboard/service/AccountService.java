package com.sbi.dashboard.service;

	import java.util.List;

	import org.springframework.stereotype.Service;

	import com.sbi.dashboard.entity.Account;

	@Service
	public interface AccountService {
		
		List<Account> getAllAccountsSingleCustomerService(int custID);

	}


