package com.sbi.dashboard.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.dashboard.entity.Transaction;
import com.sbi.dashboard.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {
	
	@Autowired
	TransactionRepository txnRepo;

	@Override
	public void fundTransferService(String narration, int sAcc, int dAcc, int txnAmt) {
		// TODO Auto-generated method stub	
		
		txnRepo.fundTransfer(narration, sAcc, dAcc,txnAmt);
	}
	
	
	
	

}
