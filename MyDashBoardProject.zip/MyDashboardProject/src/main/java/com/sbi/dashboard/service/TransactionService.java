package com.sbi.dashboard.service;

import org.springframework.stereotype.Service;

import com.sbi.dashboard.entity.Transaction;

@Service
public interface TransactionService {
	
	void fundTransferService(String narration, int sAcc, int dAcc, int txnAmt);

}
