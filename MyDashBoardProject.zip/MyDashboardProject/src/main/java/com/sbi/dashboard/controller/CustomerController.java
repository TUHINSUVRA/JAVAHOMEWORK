package com.sbi.dashboard.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.exceptions.CustomerNotFoundException;
import com.sbi.dashboard.service.CustomerService;


@CrossOrigin
@RestController
@RequestMapping("/cust")
public class CustomerController {

	
	
@Autowired	
CustomerService customerservice;
	
@RequestMapping(path = "/{cno}")
	public Customer getCustomerByIdController(@PathVariable("cno") int custNo) {
	
	System.out.println("getCustomerByIdController started" +custNo);
	return customerservice.getCustomerByIdService(custNo);
}
	
@PutMapping("/updateProfile/{cno}")
public String updateExistingProfile(@PathVariable("cno") int custNo) throws CustomerNotFoundException   {
	System.out.println("department controller: updateExistingDepartment() is invoked");

		try {
			
			customerservice.modifyCustomerService(custNo);
		} catch (CustomerNotFoundException e) {
			// TODO Auto-generated catch block
			throw e;
		}
		return "Profile updated successfully....";
}






}