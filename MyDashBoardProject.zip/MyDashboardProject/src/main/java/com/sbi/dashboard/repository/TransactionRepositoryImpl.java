package com.sbi.dashboard.repository;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.dashboard.entity.Account;
import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.entity.Transaction;

@Repository("txnRepo")
public class TransactionRepositoryImpl implements TransactionRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Transactional
	public void fundTransfer(String narration, int sAcc, int dAcc, int txnAmt) {
		// TODO Auto-generated method stub
		int newBalSA;
		int newBalDA;
		
		Customer cust = entityManager.find(Customer.class, 105);
		Account source = entityManager.find(Account.class, sAcc);		
		System.out.println("Source Account No is:"+source.getAccNumber());
		System.out.println("Source Account Balance is:"+source.getAccBalance());
		
		Account destination = entityManager.find(Account.class, dAcc);
		System.out.println("Destination Account No is:"+destination.getAccNumber());
		System.out.println("Destination Account Balance is:"+destination.getAccBalance());
		
		if(txnAmt>=source.getAccBalance()) {
			System.out.println("Insufficient Funds in your Account......FAKIR HO AAP");
		}else {
			System.out.println("BALANnce BEFFORE DEBIT in SOURCE\""+source.getAccBalance());
			newBalSA=source.getAccBalance()-txnAmt;
			System.out.println("JAVA BALANCE"+newBalSA);
			source.setAccBalance(newBalSA);
			System.out.println("BALANnce AFTER DEBIT in SOURCE"+source.getAccBalance());
			entityManager.merge(source);
			
			System.out.println("BALANnce BEFFORE Credit in DEstination"+destination.getAccBalance());
			newBalDA=destination.getAccBalance()+txnAmt;
			System.out.println("JAVA BALANCE"+newBalDA);
			destination.setAccBalance(newBalDA);
			System.out.println("BALANnce AFTER Credit in DEstination"+destination.getAccBalance());
			entityManager.merge(destination);
			
			System.out.println("DATE IS:"+LocalDate.now());
			
			//entityManager.persist(new Transaction("DEFAULT",sAcc,dAcc,"DEBIT","CREDIT","SUCCESS",txnAmt,LocalDate.now(),"Payment",105));
		
			Transaction nowTxn=new Transaction();
			nowTxn.setAccSA(source);
			nowTxn.setAccDA(destination);
			nowTxn.setTxnTypeSA("DEBIT");
			nowTxn.setTxnTypeDA("CREDIT");
			nowTxn.setTxnStatus("SUCCESS");
			nowTxn.setTxnAmount(txnAmt);
			Calendar cal = Calendar.getInstance();
			java.util.Date date = cal.getTime();
			java.sql.Date now = new java.sql.Date(date.getTime());
			nowTxn.setTxnDate(now);
			nowTxn.setTxnComments(narration);
			entityManager.persist(nowTxn);
		}
	}

}
