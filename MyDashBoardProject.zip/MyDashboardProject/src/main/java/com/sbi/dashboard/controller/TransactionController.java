package com.sbi.dashboard.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.dashboard.service.CustomerService;
import com.sbi.dashboard.service.TransactionService;

@CrossOrigin
@RestController
@RequestMapping("/transfer")
public class TransactionController {
	
	@Autowired	
	TransactionService txnService;
	
	@GetMapping(path = "/{comments}/{sAcc}/{dAcc}/{txnAmt}")
	public String transactionController(@PathVariable("comments")String narration,
			@PathVariable("sAcc")int sAcc,
			@PathVariable("dAcc")int dAcc,
			@PathVariable("txnAmt")int txnAmt
			) {
		
		txnService.fundTransferService(narration,sAcc, dAcc,txnAmt);
	
		return "TRANSACTION SUCCESSFUL";
	}
	
	

}
