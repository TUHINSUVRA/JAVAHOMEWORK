package com.sbi.dashboard.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(name="address")
public class Address  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ADDRESS_ID")
	int addId;                 		//NOT NULL NUMBER
	
	@Column(name="FLAT_NO")
	String flatNO;						// NOT NULL VARCHAR2(30)
	
	@Column(name="STREET_NAME")
	String streetname;          		//NOT NULL VARCHAR2(50)
	
	@Column(name="CITY")
	String city;        				//NOT NULL VARCHAR2(30)
	
	@Column(name="STATE")
	String state;						//NOT NULL VARCHAR2(30) 
    
    @Column(name="COUNTRY")
    String country;						//NOT NULL VARCHAR2(10)
    
    @Column(name="PIN")
	int pin;								//NOT NULL NUMBER
    
    
    @OneToOne
	@JoinColumn(name="CUST_NO")
	private Customer customer;


	public int getAddId() {
		return addId;
	}


	public void setAddId(int addId) {
		this.addId = addId;
	}


	public String getFlatNO() {
		return flatNO;
	}


	public void setFlatNO(String flatNO) {
		this.flatNO = flatNO;
	}


	public String getStreetname() {
		return streetname;
	}


	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public int getPin() {
		return pin;
	}


	public void setPin(int pin) {
		this.pin = pin;
	}


	@JsonIgnore
	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
  
    

}
