package com.sbi.dashboard.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.repository.CustomerRepository;


@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepo;
	
	@Override
	public Customer getCustomerByIdService(int custNo) {
		
		return customerRepo.getCustomerById(custNo);
		
	}

}
