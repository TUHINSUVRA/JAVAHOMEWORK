package com.sbi.dashboard.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.exceptions.CustomerNotFoundException;
import com.sbi.dashboard.repository.CustomerRepository;



@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepo;
	
	@Override
	public Customer getCustomerByIdService(int custNo) {
		
		return customerRepo.getCustomerById(custNo);
		
	}
	
	
	

	@Transactional
	public void modifyCustomerService(int custNo) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		try {
			customerRepo.updateProfile(custNo);
		} catch (CustomerNotFoundException e) {
			// TODO Auto-generated catch block
			throw e;
		}
		
	}

		
	}


