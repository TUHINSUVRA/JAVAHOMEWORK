package com.sbi.dashboard.exceptions;

public class DepartmentAlreadyExistsException extends Exception {
	public DepartmentAlreadyExistsException(String msg) {
		super(msg);
	}
}
