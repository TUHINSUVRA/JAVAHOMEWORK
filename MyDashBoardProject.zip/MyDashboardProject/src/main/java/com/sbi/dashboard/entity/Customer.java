package com.sbi.dashboard.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;



@Component
@Entity
@Table(name="customer_dashboard")
public class Customer {
	
	@Id
	@Column(name="CUST_ID")
	private int custNO;   //NOT NULL NUMBER
	
	@Column(name="NAME")
	private String custName  ;   // NOT NULL VARCHAR2(50)
	
	@Column(name="EMAIL")
	 private String custEmail ;     //  NOT NULL VARCHAR2(50)
	
	 @Column(name="MOBILE")
	 private String  custMo  ;    //  NOT NULL NUMBER
	 
	 @Column(name="DATE_OF_BIRTH")
	private Date  custDob    ;  // NOT NULL DATE
	 
	@Column(name="PAN_NUMBER")
	 private String custPan ;   // NOT NULL VARCHAR2(10)
	
	 @Column(name="ADDRESS_ID")
	 private String custAddId;    //  NOT NULL NUMBER

	public int getCustNO() {
		return custNO;
	}

	public void setCustNO(int custNO) {
		this.custNO = custNO;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public String getCustMo() {
		return custMo;
	}

	public void setCustMo(String custMo) {
		this.custMo = custMo;
	}

	public Date getCustDob() {
		return custDob;
	}

	public void setCustDob(Date custDob) {
		this.custDob = custDob;
	}

	public String getCustPan() {
		return custPan;
	}

	public void setCustPan(String custPan) {
		this.custPan = custPan;
	}

	public String getCustAddId() {
		return custAddId;
	}

	public void setCustAddId(String custAddId) {
		this.custAddId = custAddId;
	}
	 
	 
	 
	 
}
