package com.sbi.dashboard.entity;


import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;


@Component
@Entity
@Table(name="customer_dashboard")
public class Customer {

	@Id
	@Column(name="CUST_ID")
	private int custNO;   //NOT NULL NUMBER
	
	@Column(name="NAME")
	private String custName  ;   // NOT NULL VARCHAR2(50)
	
	@Column(name="EMAIL")
	 private String custEmail ;     //  NOT NULL VARCHAR2(50)
	
	 @Column(name="MOBILE")
	 private String  custMo  ;    //  NOT NULL NUMBER
	 
	 @Column(name="DATE_OF_BIRTH")
	private Date  custDob    ;  // NOT NULL DATE
	 
	@Column(name="PAN_NUMBER")
	 private String custPan ;   // NOT NULL VARCHAR2(10)

	 
	 @OneToOne(mappedBy="customer",fetch = FetchType.LAZY, cascade = CascadeType.ALL)
		private Address address;
	 
	 
	 
	 @OneToMany(mappedBy="customer1", fetch = FetchType.LAZY, cascade = CascadeType.ALL )
		private List<Account> acountList;

	// @OneToMany(mappedBy="txnCustID", fetch = FetchType.EAGER, cascade = CascadeType.ALL )
	//	private List<Transaction> txnList;



	public int getCustNO() {
		return custNO;
	}



	public void setCustNO(int custNO) {
		this.custNO = custNO;
	}



	public String getCustName() {
		return custName;
	}



	public void setCustName(String custName) {
		this.custName = custName;
	}



	public String getCustEmail() {
		return custEmail;
	}



	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}



	public String getCustMo() {
		return custMo;
	}



	public void setCustMo(String custMo) {
		this.custMo = custMo;
	}



	public Date getCustDob() {
		return custDob;
	}



	public void setCustDob(Date custDob) {
		this.custDob = custDob;
	}



	public String getCustPan() {
		return custPan;
	}



	public void setCustPan(String custPan) {
		this.custPan = custPan;
	}



	public Address getAddress() {
		return address;
	}



	public void setAddress(Address address) {
		this.address = address;
	}



	@JsonIgnore
	public List<Account> getAcountList() {
		return acountList;
	}



	public void setAcountList(List<Account> acountList) {
		this.acountList = acountList;
	}
	/*
	public List<Transaction> getTxnList() {
		return txnList;
	}

	public void setTxnList(List<Transaction> txnList) {
		this.txnList = txnList;
	}
*/




	
	 
	 
}
