package com.sbi.dashboard.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.sbi.dashboard.entity.Customer;

@Repository
public class CustomerRepositoryImpl implements CustomerRepository {
	
	@PersistenceContext    
	EntityManager em; 
	

	@Override
	public Customer getCustomerById(int id) {
		
		Customer cust=em.find(Customer.class, id);
			
		return cust;
	}
	
	

}
