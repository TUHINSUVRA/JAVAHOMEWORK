package com.sbi.dashboard.repository;

import javax.mail.Address;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.exceptions.CustomerNotFoundException;
//import com.sbi.dashboard.entity.Address;


@Repository
public class CustomerRepositoryImpl implements CustomerRepository {
	
	@PersistenceContext    
	EntityManager em; 
	

	@Override
	public Customer getCustomerById(int id) {
	
		Customer cust=em.find(Customer.class, id);
		
		System.out.println(cust.getAddress());
		
		return cust;
	
	}


	@Transactional
	public void updateProfile(int custNo) throws CustomerNotFoundException
	{
		Customer custTemp = em.find(Customer.class, custNo);
		if(custTemp == null) {
			throw new CustomerNotFoundException("Department NOT found : ");
		}
		
		em.merge(custTemp);
	}
	

}
