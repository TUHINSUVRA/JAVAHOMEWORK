
package com.sbi.dashboard.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.format.datetime.standard.TemporalAccessorPrinter;
import org.springframework.stereotype.Repository;

import com.sbi.dashboard.entity.Account;
import com.sbi.dashboard.entity.Customer;

@Repository("acctRepo")
public class AccountRepositoryImpl implements AccountRepository {
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Account> getAllAccountsSingleCustomer(int custId) {
		// TODO Auto-generated method stub
		
		List<Account> accList = null;
		
		try {
			//TypedQuery<Account> query = entityManager.createQuery("from Account where customerAccountNo="+custId, Account.class);
			//accList = query.getResultList();
			Customer cust=entityManager.find(Customer.class, custId);
			accList=cust.getAcountList();
			for(Account accPrint:accList) {
				System.out.println("Printing Acc Number:"+accPrint.getAccNumber());
				System.out.println("Printint Acc Type:"+accPrint.getAccType());
				System.out.println("Printing Acc Balance:"+accPrint.getAccBalance());
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Account Repository Impl : getAllAccount() is returning list....");
		return accList;
		
	}

}
