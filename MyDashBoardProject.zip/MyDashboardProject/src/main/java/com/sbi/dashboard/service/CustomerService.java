package com.sbi.dashboard.service;

import org.springframework.stereotype.Service;

import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.exceptions.CustomerNotFoundException;


@Service
public interface CustomerService {

	Customer getCustomerByIdService(int custNo);
	void modifyCustomerService(int custNo)  throws CustomerNotFoundException;
}
