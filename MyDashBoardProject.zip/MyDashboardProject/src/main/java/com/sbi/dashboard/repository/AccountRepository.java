
	package com.sbi.dashboard.repository;

	import java.util.List;

	import org.springframework.stereotype.Repository;

	import com.sbi.dashboard.entity.Account;

	@Repository
	public interface AccountRepository {
		
		List<Account> getAllAccountsSingleCustomer(int custId);

	}


