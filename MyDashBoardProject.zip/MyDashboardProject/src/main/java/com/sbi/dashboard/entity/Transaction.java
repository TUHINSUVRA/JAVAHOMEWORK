package com.sbi.dashboard.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Component
@Entity
@Table(name="transaction")
public class Transaction {
	
	@Id
	@GeneratedValue	(strategy = GenerationType.IDENTITY)
	@Column(name="TRANSACTION_ID")
	private int txnId;					//	TRANSACTION_ID      NOT NULL NUMBER(38)   
	
//	@Column(name="SOURCE_ACCOUNT")
//	private int txnSourceAcc;			//	SOURCE_ACCOUNT      NOT NULL NUMBER 
//	
//	@Column(name="DESTINATION_ACCOUNT")
//	private int txnDestAcc;				//	DESTINATION_ACCOUNT NOT NULL NUMBER 
	
	@Column(name="TRANSACTION_TYPE_SA")
	private String txnTypeSA;			//	TRANSACTION_TYPE_SA          VARCHAR2(15) 
	
	@Column(name="TRANSACTION_TYPE_DA")
	private String txnTypeDA;			//	TRANSACTION_TYPE_DA          VARCHAR2(15) 
	
	@Column(name="TRANSACTION_STATUS")
	private String txnStatus;			//	TRANSACTION_STATUS           VARCHAR2(15) 
	
	@Column(name="TRANSACTION_AMOUNT")
	private int txnAmount;			//	TRANSACTION_AMOUNT           NUMBER 
	
	@Column(name="TRANSACTION_DATE")
	private Date txnDate;				//	TRANSACTION_DATE             DATE 
	
	@Column(name="COMMENTS")
	private String txnComments;			//	COMMENTS                     VARCHAR2(30) 
	
	//@ManyToOne
	//@JoinColumn(name="CUST_ID")
	//private Customer txnCustID;				//	CUST_ID             NOT NULL NUMBER(38) 
	
	@ManyToOne
	@JoinColumn(name="SOURCE_ACCOUNT")					
	private Account accSA;
	
	@ManyToOne
	@JoinColumn(name="DESTINATION_ACCOUNT")					
	private Account accDA;

	

//	public int getTxnSourceAcc() {
//		return txnSourceAcc;
//	}
//
//	public void setTxnSourceAcc(int txnSourceAcc) {
//		this.txnSourceAcc = txnSourceAcc;
//	}
//
//	public int getTxnDestAcc() {
//		return txnDestAcc;
//	}
//
//	public void setTxnDestAcc(int txnDestAcc) {
//		this.txnDestAcc = txnDestAcc;
//	}

	public int getTxnId() {
		return txnId;
	}

	public void setTxnId(int txnId) {
		this.txnId = txnId;
	}

	public String getTxnTypeSA() {
		return txnTypeSA;
	}

	public void setTxnTypeSA(String txnTypeSA) {
		this.txnTypeSA = txnTypeSA;
	}

	public String getTxnTypeDA() {
		return txnTypeDA;
	}

	public void setTxnTypeDA(String txnTypeDA) {
		this.txnTypeDA = txnTypeDA;
	}

	public String getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(String txnStatus) {
		this.txnStatus = txnStatus;
	}

	public int getTxnAmount() {
		return txnAmount;
	}

	public void setTxnAmount(int txnAmount) {
		this.txnAmount = txnAmount;
	}

	public Date getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}

	public String getTxnComments() {
		return txnComments;
	}

	public void setTxnComments(String txnComments) {
		this.txnComments = txnComments;
	}
/*
	@JsonIgnore
	public Customer getTxnCustID() {
		return txnCustID;
	}

	public void setTxnCustID(Customer txnCustID) {
		this.txnCustID = txnCustID;
	}*/

	@JsonIgnore
	public Account getAccSA() {
		return accSA;
	}

	public void setAccSA(Account accSA) {
		this.accSA = accSA;
	}

	@JsonIgnore
	public Account getAccDA() {
		return accDA;
	}

	public void setAccDA(Account accDA) {
		this.accDA = accDA;
	}

	
}
