package com.sbi.dashboard.repository;

import org.springframework.stereotype.Repository;

import com.sbi.dashboard.entity.Customer;

@Repository
public interface CustomerRepository {
	
	Customer getCustomerById(int id);

}
