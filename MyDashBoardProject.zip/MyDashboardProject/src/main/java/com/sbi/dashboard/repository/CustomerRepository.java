package com.sbi.dashboard.repository;



import org.springframework.stereotype.Repository;

import com.sbi.dashboard.entity.Address;
import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.exceptions.CustomerNotFoundException;


@Repository
public interface CustomerRepository {
	
	Customer getCustomerById(int id);
	void updateProfile(int id) throws CustomerNotFoundException;
	
}
