package com.sbi.dashboard.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Component
@Entity
@Table(name="account")
public class Account {

	
	@Id
	@Column(name="ACCOUNT_NUMBER")
	private int accNumber;						//	    NOT NULL NUMBER
	
	@Column(name="BALANCE")
	private int accBalance;					//	    NUMBER
	
	@Column(name="LIMIT")
	private int accLimit;					//	    NUMBER
	
	@Column(name="OPEN_DATE")
	private Date accOpenDate;					//	    DATE
	
	@Column(name="RATE_OF_INTEREST")
	private float accROI;						//	    NUMBER(3,2)
	
	@Column(name="ACCOUNT_TYPE")
	private String accType;						//	    VARCHAR2(15)
	
	
	@Column(name="BRANCH_NAME")
	private String accBranch;
	
	@ManyToOne
	@JoinColumn(name="CUST_ID")					
	private Customer customer1; 			//	    NOT NULL NUMBER
	
	@OneToMany(mappedBy="accSA", fetch = FetchType.EAGER, cascade = CascadeType.ALL )
	private List<Transaction> txnListSA;
	
	@OneToMany(mappedBy="accDA", fetch = FetchType.EAGER, cascade = CascadeType.ALL )
	private List<Transaction> txnListDA;
	
	

	public String getAccBranch() {
		return accBranch;
	}

	public void setAccBranch(String accBranch) {
		this.accBranch = accBranch;
	}

	public int getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}

	public int getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(int accBalance) {
		this.accBalance = accBalance;
	}

	public int getAccLimit() {
		return accLimit;
	}

	public void setAccLimit(int accLimit) {
		this.accLimit = accLimit;
	}

	public Date getAccOpenDate() {
		return accOpenDate;
	}

	public void setAccOpenDate(Date accOpenDate) {
		this.accOpenDate = accOpenDate;
	}

	public float getAccROI() {
		return accROI;
	}

	public void setAccROI(float accROI) {
		this.accROI = accROI;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	@JsonIgnore
	public Customer getCustomer1() {
		return customer1;
	}

	public void setCustomer1(Customer customer1) {
		this.customer1 = customer1;
	}
	
	@JsonIgnore
	public List<Transaction> getTxnListSA() {
		return txnListSA;
	}

	public void setTxnListSA(List<Transaction> txnListSA) {
		this.txnListSA = txnListSA;
	}
	
	@JsonIgnore
	public List<Transaction> getTxnListDA() {
		return txnListDA;
	}

	public void setTxnListDA(List<Transaction> txnListDA) {
		this.txnListDA = txnListDA;
	}

	
}
