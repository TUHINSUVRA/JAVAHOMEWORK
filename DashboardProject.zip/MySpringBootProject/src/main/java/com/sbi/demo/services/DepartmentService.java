package com.sbi.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.DepartmentAlreadyExistsException;
import com.sbi.demo.exceptions.DepartmentNotFoundException;

@Service
public interface DepartmentService {
	List<Department> fetchAllDepartmentsService();
	
	Department fetchDepartmentByIdService(int deptno) throws DepartmentNotFoundException ;
	
	void addDepartmentService(Department dept) throws DepartmentAlreadyExistsException;
	void modifyDepartmentService(Department dept)  throws DepartmentNotFoundException;
	void deleteDepartmentByIdService(int deptno)  throws DepartmentNotFoundException;
	
}
