package com.sbi.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name="dept")
public class Department {
	@Id
	@Column(name="DEPTNO")
	private int departmentNO;
	
	@Column(name="DNAME")
	private String departmentName;
	
	@Column(name="LOC")
	private String departmentlocation;

	public int getDepartmentNO() {
		return departmentNO;
	}

	public void setDepartmentNO(int departmentNO) {
		this.departmentNO = departmentNO;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentlocation() {
		return departmentlocation;
	}

	public void setDepartmentlocation(String departmentlocation) {
		this.departmentlocation = departmentlocation;
	}


	
	
	
	

}
