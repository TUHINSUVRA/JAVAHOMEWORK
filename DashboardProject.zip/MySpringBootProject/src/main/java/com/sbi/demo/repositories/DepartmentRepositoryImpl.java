package com.sbi.demo.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.DepartmentAlreadyExistsException;
import com.sbi.demo.exceptions.DepartmentNotFoundException;
@Repository("deptRepo")
public class DepartmentRepositoryImpl implements DepartmentRepository  {
	
	//EntityManagerFactory emf;
	
	
	
	@PersistenceContext    //no need to create  EntityManagerFactory emf object to access EntityManager
	EntityManager em; 

	public DepartmentRepositoryImpl() {
		//emf=Persistence.createEntityManagerFactory("MyJPA");
		//em=emf.createEntityManager();
		System.out.println("DepartmentRepositoryImpl()....");
		
	}
	
	@Override
	public List<Department> getAllDepartments() {
		TypedQuery<Department> query = em.createQuery("from Department", Department.class);
		return query.getResultList();	
	
	}

	@Override
	public Department getDepartmentById(int id) throws DepartmentNotFoundException
	{
		Department dept = em.find(Department.class, id);
		if(dept==null) {
			throw new DepartmentNotFoundException("Department NOT found : "+id);
		}
		return dept;
		
	}

	@Transactional
	public void insertDepartment(Department dept)throws DepartmentAlreadyExistsException 
	{
		Department deptTemp = em.find(Department.class, dept.getDepartmentNO());
		if(deptTemp!=null) {
			throw new DepartmentAlreadyExistsException("This department number already exists!!!! : "+deptTemp.getDepartmentNO());
		}
		em.persist(dept);
	}
	@Transactional
	public void updateDepartment(Department dept) throws DepartmentNotFoundException
	{
		Department deptTemp = em.find(Department.class, dept.getDepartmentNO());
		if(deptTemp == null) {
			throw new DepartmentNotFoundException("Department NOT found : "+dept.getDepartmentNO());
		}
		
		em.merge(dept);
	}
	@Transactional
	public void deleteDepartmentById(int id) throws DepartmentNotFoundException{
		Department dept = em.find(Department.class,id);
		if(dept==null){
			throw new DepartmentNotFoundException("Department NOT found : "+id);
		}
		em.remove(dept);
	}

}
