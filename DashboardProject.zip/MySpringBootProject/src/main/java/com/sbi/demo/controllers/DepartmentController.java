package com.sbi.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.DepartmentAlreadyExistsException;
import com.sbi.demo.exceptions.DepartmentNotFoundException;
import com.sbi.demo.services.DepartmentService;
@CrossOrigin
@RestController
@RequestMapping("/depts")
public class DepartmentController { // localhost:8080/depts/welcome
	
	
	@RequestMapping("/welcome")
	public String greet() {
		System.out.println("greet() invoked....");
		return "<h1> welcome to dept </h1>";
	}
	
	@Autowired
	DepartmentService deptService;
	
	@RequestMapping("/")
	public List<Department> getAll() {
		
		System.out.println("getAll() invoked....");
//		List<Department> deptList= deptService.fetchAllDepartmentsService();
//	for (Department department : deptList) {
//		System.out.println("DEPTNO : "+department.getDepartmentNO());
//			System.out.println("DNAME  : "+department.getDepartmentName());
//			System.out.println("DLOC   : "+department.getDepartmentlocation());
//			System.out.println("----------------------------------");
//	}
		
		return deptService.fetchAllDepartmentsService();
		}
	
	@RequestMapping("/{dno}")
	public Department findSingleDepartment(@PathVariable("dno")int deptno) throws DepartmentNotFoundException {
		System.out.println("DepartmentController: findSingleDept(int) is invoked....");
		  Department dept=null;
		  try {
			dept = deptService.fetchDepartmentByIdService(deptno);
		  } catch (DepartmentNotFoundException e) {
			//return ResponseEntity.status(404).build();
			  throw e;
		  }
		  //return ResponseEntity.ok().body(dept);
		  return dept;
	}
	@PostMapping("/addDept")
	public String addNewDepartment(@RequestBody Department deptBody) throws DepartmentAlreadyExistsException  {
		System.out.println("department controller: addNewDepartment() is invoked");
		try {
			deptService.addDepartmentService(deptBody);
		} catch (DepartmentAlreadyExistsException e) {
			// TODO Auto-generated catch block
			throw e;
		}
		
		return "Department added successfully....";
		
		}
	
	
	
	
	@PutMapping("/updateDept")
	public String updateExistingDepartment(@RequestBody Department deptBody) throws DepartmentNotFoundException   {
		System.out.println("department controller: updateExistingDepartment() is invoked");
	
			try {
				deptService.modifyDepartmentService(deptBody);
			} catch (DepartmentNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			return "Department updated successfully....";
	}
	
	
	@DeleteMapping("/deleteDept/{id}")
	public void deleteExistingDepartment(@PathVariable("id")int deptNoToDelete )  throws DepartmentNotFoundException {
		
		System.out.println("DepartmentController: deleteExistingDepartment(Department) is invoked....");
		  try {
			deptService.deleteDepartmentByIdService(deptNoToDelete);
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}