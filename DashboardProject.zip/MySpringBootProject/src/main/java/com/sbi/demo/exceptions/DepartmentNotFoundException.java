package com.sbi.demo.exceptions;

public class DepartmentNotFoundException extends Exception {
	public DepartmentNotFoundException(String msg) {
		super(msg);
	}
}
