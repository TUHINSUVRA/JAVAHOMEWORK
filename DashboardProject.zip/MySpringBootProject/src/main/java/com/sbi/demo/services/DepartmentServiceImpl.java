package com.sbi.demo.services;

import java.util.List;
import java.util.Scanner;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.DepartmentAlreadyExistsException;
import com.sbi.demo.exceptions.DepartmentNotFoundException;
import com.sbi.demo.repositories.DepartmentRepository;

@Service		//4
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired		// 3
	DepartmentRepository deptRepository;
	
	@Override
	public List<Department> fetchAllDepartmentsService() {
		
		return deptRepository.getAllDepartments();
//		Scanner scan1 = new Scanner(System.in);
//		Scanner scan2 = new Scanner(System.in);
//		
//		System.out.println("Enter username : ");
//		String username = scan1.next();
//		System.out.println("Enter password : ");
//		String password = scan2.next();
//		
//		if(username.equals("admin") && password.equals("admin123")) {
//			System.out.println("Welcome admin...");
//		List<Department> deptList= deptRepository.getAllDepartments();
//			for (Department department : deptList) {
//				System.out.println("DEPTNO : "+department.getDepartmentNO());
//			System.out.println("DNAME  : "+department.getDepartmentName());
//			System.out.println("DLOC   : "+department.getDepartmentlocation());
//				System.out.println("----------------------------------");
//			}
			
//		}
//		else {
//			throw new RuntimeException("Only admin can view all the departments...");
//		}
	}

	
	public Department fetchDepartmentByIdService(int id) throws DepartmentNotFoundException
	{
		Department dept=null;
		try {
			dept = deptRepository.getDepartmentById(id);
		} catch (DepartmentNotFoundException e) {
			throw e;
		}
		return dept;
	}

	@Transactional
	public void addDepartmentService(Department dept) throws DepartmentAlreadyExistsException {
		 try {
			deptRepository.insertDepartment(dept);
		} catch (DepartmentAlreadyExistsException e) {
			// TODO Auto-generated catch block
			throw e;
		}
		
	}

	@Transactional
	public void modifyDepartmentService(Department dept) throws DepartmentNotFoundException {
		try {
			deptRepository.updateDepartment(dept);
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			throw e;
		}
		
	}

	@Transactional

		public void deleteDepartmentByIdService(int deptno) throws DepartmentNotFoundException{
			try {
				deptRepository.deleteDepartmentById(deptno);
			} 
			catch (DepartmentNotFoundException e) {
					throw e;
			}
		}
}
