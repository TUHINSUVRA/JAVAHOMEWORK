package com.sbi.demo.exceptions;

public class DepartmentAlreadyExistsException extends Exception {
	public DepartmentAlreadyExistsException(String msg) {
		super(msg);
	}
}
